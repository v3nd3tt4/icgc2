<?php
include 'header.php';
include 'navbar.php';
include 'content.php';
include 'sidebar.php';
include 'footer.php';