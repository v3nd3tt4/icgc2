 <div class="col-md-9">
	<br/>
	<div class="panel panel-default">
		<div class="panel-heading">
			<i class="fa fa-info" aria-hidden="true"></i> Organizatoring Committee
		</div>
		<div class="panel-body">
			<ol>
				<li>Assoc.Prof.Andi Thahir, S.Psi.,M.A.,Ed.D, General Chair</li>
				<li>Okta Pilopa, M.T.I, Program Chair</li>
				<ol>
					<li>Rahmat Alfian, Member </li>
					<li>Wafi Hibatullah, Member </li>
				</ol>
				
				<li>Rahma Diani, M.Pd, Publications Chair</li>
				<ol>
					<li>Iip Sugiharta, M.Si, Member</li>
					<li>Siti Zahra Bulantika, M.Pd, Member</li>
					<li>Tri Dewantari, M.Pd, Member</li>
				</ol>
				
				<li>Anisa Mawarni, M.Pd, Patronage Chair</li>
					<ol>
						<li>Citra Abriani Maharani, M.Pd., Kons, Member</li>
						<li>Mujiati, M.Pd, Member</li>
					</ol>
				<li>Dra. Kholina, M.Pd, Treasurer</li>
			</ol>
			
		</div>
	</div>
</div>