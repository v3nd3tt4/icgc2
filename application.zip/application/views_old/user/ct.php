 <div class="col-md-9">
	<br/>
	<div class="panel panel-default">
		<div class="panel-heading">
			<i class="fa fa-info" aria-hidden="true"></i> Conference Topic
		</div>
		<div class="panel-body">
			<ol>
				<li>Assessment, testing, and program evaluation</li> 
				<li>Career development and employment </li>
				<li>Child and adolescent </li>
				<li>Marriage, family and Community Guidance and Counseling</li>
				<li>Human rights, social justice, and legal issues </li>
				<li>Individual trauma and Crisis Counseling</li>
				<li>Multicultural, peace and social wellbeing </li>
				<li>Holistic wellbeing of Youth and children in the digital era</li>
				<li>Productive adulthood  and aging well</li>
				<li>Environment justice and climate change</li>
				<li>Optimizing human resource and organizational performance </li>
				<li>Rehabilitation  and disability</li> 
				<li>School and college guidance and counseling</li>
				<li>Spiritual and religion Guidance and Counseling</li>
				<li>Technology and Social Media in Guidance and Counseling </li>
				<li>Integrated of local and indigenous knowledge</li>
				<li>Counseling and Mental Health</li>
			</ol>
			
		</div>
	</div>
</div>