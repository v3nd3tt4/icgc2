 <div class="col-md-9">
	<br/>
	<div class="panel panel-default">
		<div class="panel-heading">
			<i class="fa fa-info" aria-hidden="true"></i> Keynote Speaker
		</div>
		<div class="panel-body">
			<ol>
				<!-- <li>Dr. Melfi M. Caranto (Dean, College of Liberal Arts, Criminology and Education Jose Rizal University)</li> -->
				<li>Prof. Jacobus G. Maree, D.Ed, Ph.D., D.Phil (Department of Educational Psychology, University of Pretoria.
South Africa)</li>
				<li>Dr. Norhayati Mohd Noor (Universiti Kebangsaan Malaysia, Faculty of Education)</li>
				<li>Dr. Supriano, M.Ed.Dirjen GTK Kemendikbud Indonesia</li>
				<li>Dr. Moh.Farozin, (KetuaUmumPB ABKIN,  Univ Negeri Yogjakarta)</li>
				<li>Prof. Dr. H. Suyitno, M.Ag, (DirekturDit. GTK Madrasah. KEMENAG RI)</li>
			</ol>
			
		</div>
	</div>
</div>