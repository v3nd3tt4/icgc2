<div class="col-md-9">
	<br/>
	<div class="panel panel-default">
		<div class="panel-heading">
			<i class="fa fa-file-text-o" aria-hidden="true"></i> Procedure
		</div>
		<div class="panel-body">
		</div>
	</div>
</div>