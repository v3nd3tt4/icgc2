 <div class="col-md-9">
	<br/>
	<div class="panel panel-default">
		<div class="panel-heading">
			<i class="fa fa-info" aria-hidden="true"></i> Scientific Committee
		</div>
		<div class="panel-body">
			<ol>
				<li>Gysbers, Norman C University of Missouri System, Columbia, United States</li> 
				<li>Yeo Kee Jiar, Universiti Teknologi Malaysia, Skudai, Malaysia </li>
				<li>Bunga citra pertiwi, Faculty der Sociale Wetenschappen Instituut Psychologie Methodologie </li>
				<li>Prof. Dr. Kobus Maree, University of Pretoria South Africa </li>
				<li>Nur Demirbaş Çelik, Alanya Alaaddin Keykubat University, Education of Science, </li>
				<li>Prof.Dr. Demet Erol, kdeniz University, Turkey </li>
				<li>Colette T. Dollarhide The Ohio State University , United States </li>
				<li>Pamelia E. Brott, PhD, LPC (MI), NCC, ACS, DCC. Counselor Education, University of Tennessee , United States </li>
				<li>Prof. dr. sc. Dubravka Miljković, University of Zagreb, Croatia </li>
				<li>Ozlem Karaırmak, Bahcesehir University, Turkey </li>
				<li>Rui Gomes, University of Minho, Portugal</li> 
				<li>Akbar Salehi, Kharazmi University, Iran </li>
				<li>Prof. Aldert Vrij, University of Portsmouth, UK </li>
				<li>Prof. Andrew Day Deakin, University, Australia </li>
				<li>Anthony L. Pillay University of KwaZulu-Natal </li>
				<li>Bea Van den Bergh, Tilburg University, The Netherlands </li>
				<li>Professor Chris McVittie, Queen Margaret University, Scotland </li>
				<li>Conchi San Martín, University of Barcelona, Spain </li>
				<li>Diane Sunar, Bilgi University, Turkey </li>
				<li>Prof Dt Zaidy Mohd Zain, Texas University</li>
			</ol>
			
		</div>
	</div>
</div>