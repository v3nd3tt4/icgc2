            </div>
        <!--end row -->
        </div>
    <!--end conatiner -->
    </div>

<div class="container footer">
    <div class="row">
        <div class="col-md-12">
            <center>Powered by  <a href="<?=base_url()?>welcome/counselee">counselee</a> &copy; 2019</center>
        </div>
    </div>
    <!-- <div class="row">
        <div class="col-md-3">
            <h2>Layanan</h2>
            <ul>
                  <li><a href="#">UPT TIK</a></li>
                  <li><a href="#">UPT Perpustakaan</a></li>
                  <li><a href="#">UPT Bahasa</a></li>
                  <li><a href="#">LPPM</a></li>
            </ul>
        </div>
        
        <div class="col-md-3">
            <h2>Unit Pelaksana Teknis</h2>
            <ul>
                  <li><a href="#">UPT TIK</a></li>
                  <li><a href="#">UPT Perpustakaan</a></li>
                  <li><a href="#">UPT Bahasa</a></li>
                  <li><a href="#">LPPM</a></li>
            </ul>
        </div>
        
        <div class="col-md-3">
            <h2>Video</h2>
            <iframe width="100%" src="https://www.youtube.com/embed/tH9r_cKELew?rel=0" frameborder="0" allowfullscreen></iframe>
        </div>
        
        <div class="col-md-3">
            <h2>Kontak</h2>
            <ul class="the-icons">
                <li>
                <i class="fa fa-map-marker"></i> Alamat : Jalan Terusan Ryacudu, Desa Way Hui, Kecamatan Jati Agung, Lampung Selatan 35365
                </li>
                <li>
                <i class="fa fa-envelope"></i> Email : pusat@itera.ac.id
                </li>
                <li>
                <i class="fa fa-phone"></i> Phone : (0721) 8030188,  (0721) 8030189
                </li>
                <li>
                <i class="fa fa-twitter"></i>
                Twitter:
                <a href="https://twitter.com/itera_PTN" target="_blank">@itera_PTN</a>
                </li>
            </ul>

        </div>
    </div> -->
</div>
<?php
if (!empty($script))$this->load->view($script);
?>
</body>
</html>