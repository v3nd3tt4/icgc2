 <div class="col-md-9">
	<br/>
	<div class="panel panel-default">
		<div class="panel-heading">
			<i class="fa fa-info" aria-hidden="true"></i> Manuscripts Publication & Indexing Proceeding Publisher
		</div>
		<div class="panel-body">
			*All presented and selected manuscript will be published in :
			<ol>
			<!-- <li><a href="http://www.jotse.org/index.php/jotse">Journal of Technology and Science Education (Scopus Q3)</a></li>
			<li><a href="http://www.pertanika.upm.edu.my/JSSH.php">Pertanika Journal of Social Sciences & Humanities (JSSH) (Scopus Q3)</a></li>
			<li><a href="http://mjli.uum.edu.my/">Malaysian Journal of Learning and Instruction (Scopus Q3)</a></li>
			<li><a href="https://www.scopus.com/sourceid/21100898670">Universal Journal of Educational Research ( Scopus)</a></li>
			<li><a href="https://www.atlantis-press.com/proceedings/all">International Proceedings (Atlantis Press Web of Science)</a></li>
			<li><a href="http://jurnal.fkip.unila.ac.id/index.php/jpp/">Jurnal Pendidikan Progresif (Sinta 2)</a></li> -->
				<li>jurnal Konseli (copernicus dan Sinta 3)</li>
				<li>Jurnal Guidena (Sinta 3)</li>
				<li>Jurnal Penelitian Pendidikan BK (Sinta 2)</li>
				<li>Jurnal pendidikan Teori dan Praktik (Sinta 3)</li>
				<li>Proceeding (Indeks Scopus)</li>
			</ol>
			<br/><br/>
			<img src="<?=base_url()?>assets/indexing2.png" width="100%">
		</div>
	</div>
</div>